/*
 * Ultima IV - Quest Of The Avatar
 * (c) Copyright 1987 Lord British
 * reverse-coded by Ergonomy Joe in 2012
 */

#include "title.h"

unsigned D_0036 = 0;
unsigned D_0038 = 0;
