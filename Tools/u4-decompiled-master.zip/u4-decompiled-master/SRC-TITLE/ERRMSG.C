/*
 * Ultima IV - Quest Of The Avatar
 * (c) Copyright 1987 Lord British
 * reverse-coded by Ergonomy Joe in 2012
 */

char huge /*D_3906*/MSG_DSKERR[] = "Disk error. Press any key to try again.";
char huge /*D_392E*/MSG_SYSERR[] = "DOS: Fatal System Error!";
